package com.pratiti.training.assignment;

public class Product {

	private static int generator = 1001;
	
	private int productId;
	private String name;
	private double price;
	private String description;
	private int stockAvailable;
	
	public Product(String name, double price, String description, int stockAvailable) {
		this.productId = generator++;
		this.name = name;
		this.price = price;
		this.description = description;
		this.stockAvailable = stockAvailable;
	}
	
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getStockAvailable() {
		return stockAvailable;
	}
	public void setStockAvailable(int stockAvailable) {
		this.stockAvailable = stockAvailable;
	}
	
	public void display() {
		System.out.println("Product ID : " + productId);
		System.out.println("Name : " + name);
		System.out.println("Price : " + price);
		System.out.println("Description : " + description);
		System.out.println("Stock Available : " + stockAvailable);
		
	}
}
