package com.pratiti.training.assignment;

public class Toy extends Product {

	private int age;

	public Toy(String name, double price, String description, int stockAvailable, int age) {
		super(name, price, description, stockAvailable);
		this.age = age;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}
	
	@Override
	public void display() {
		super.display();
		System.out.println("Age " + age);
	}
}
