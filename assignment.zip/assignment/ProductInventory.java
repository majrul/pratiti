package com.pratiti.training.assignment;

public class ProductInventory {

	private Product[] products = new Product[4];
	private int counter = 0;
	
	public void add(Product product) {
		products[counter++] = product;
	}
	
	public double billAmount(String name, int quantity) {
		for(Product product : products) {
			if(product.getName().equals(name)) {
				if(product.getStockAvailable() >= quantity) {
					double discount = calculateDiscount(product);
					double amount = (product.getPrice() - discount) * quantity;
					product.setStockAvailable(product.getStockAvailable() - quantity);
					return amount;
				}
				//else
					//throw new OrderException("Out of stock!");
			}
				
		}
		return 0; //throw new NoSuchProductException();
	}
	
	public double calculateDiscount(Product product) {
		if(product instanceof Book) {
			return (product.getPrice() * 10)/100;
		}
		else if(product instanceof Toy) {
			Toy toy = (Toy) product;
			if(toy.getAge() >= 2 && toy.getAge() <= 4)
				return (toy.getPrice() * 15)/100;
			else if(toy.getAge() >= 5 && toy.getAge() <= 6)
				return (toy.getPrice() * 5)/100;
		}
		return 0;
	}
}









