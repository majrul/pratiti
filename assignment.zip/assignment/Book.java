package com.pratiti.training.assignment;

public class Book extends Product {

	private int isbn;

	public Book(String name, double price, String description, int stockAvailable, int isbn) {
		super(name, price, description, stockAvailable);
		this.isbn = isbn;
	}

	public int getIsbn() {
		return isbn;
	}

	public void setIsbn(int isbn) {
		this.isbn = isbn;
	}
	
	@Override
	public void display() {
		super.display();
		System.out.println("ISBN : " + isbn);
	}
}
