package com.pratiti.training.assignment;

public class App {

	public static void main(String[] args) {
		ProductInventory inv = new ProductInventory();
		inv.add(new Book("The Alchemist", 250, "Nice Book", 25, 1234567890));
		inv.add(new Book("Rich Dad Poor Dad", 350, "Nice Book", 25, 987654321));
		inv.add(new Toy("Lego Blocks", 1500, "Star Wars Lego Blocks", 25, 3));
		inv.add(new Toy("Drone", 3500, "RC Drone", 25, 5));
		
		double billAmount = inv.billAmount("Lego Blocks", 2);
		System.out.println("Bill Amount " + billAmount);
		
	}
}
